The XML documents and example queries in the subdirectories are
taken from:

tree  -> Galax (http://www.galaxquery.org/)
sgml  -> Galax (http://www.galaxquery.org/)
xmark -> XMark - An XML Benchmark Project (http://www.xml-benchmark.org/)
xmp   -> Galax (http://www.galaxquery.org/)