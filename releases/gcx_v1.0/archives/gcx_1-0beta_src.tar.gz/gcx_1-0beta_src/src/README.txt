************************************************************
***************** THE GCX XQUERY ENGINE ********************
************************************************************
GCX is a streaming XQuery engine. It has been developed as
part of a research project from the Saarland University 
Database Group. You can find more information about GCX at

	http://www-db.cs.uni-sb.de/projects/streams/gcx/

------------------------------------------------------------
* See file LICENSE.txt for license information
* See file INSTALL.txt for installation instructions
------------------------------------------------------------

Please use the GCX mailing list

	http://lists.math.uni-sb.de/mailman/listinfo/gcx-users

for requests, discussion, and bug reports.
